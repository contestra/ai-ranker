import json
from brandx.service import app
from fastapi.testclient import TestClient

client = TestClient(app)

def _req(answer_text, citations=None):
    return {
        "org_id":"org1",
        "run_id":"run1",
        "answer_text": answer_text,
        "citations": citations or [],
        "brand": {
            "entity_id":"brand_avea",
            "canonical_name":"AVEA Life",
            "website_domains":["avea-life.com"],
            "signature_terms":["longevity","NAD+","spermidine","resveratrol","collagen"],
            "geo_company_hints":["Swiss","AG","Switzerland"],
            "retailer_domains":["amazon.com"]
        },
        "aliases":[
            {"alias_id":"a1","entity_id":"brand_avea","alias_text":"AVEA Life","type":"brand","risk":"low","required_evidence_mask":0},
            {"alias_id":"a2","entity_id":"brand_avea","alias_text":"AVEA","type":"brand","risk":"high","required_evidence_mask":1},
            {"alias_id":"p1","entity_id":"prod_mobilizer","alias_text":"Mobilizer","type":"product","risk":"high","required_evidence_mask":2}
        ]
    }

def test_low_risk_brand_counts():
    payload = _req("We like AVEA Life for longevity.")
    r = client.post("/v1/extract", json=payload)
    data = r.json()
    assert r.status_code == 200
    ents = {m["entity_id"] for m in data["mentions"]}
    assert "brand_avea" in ents

def test_naked_avea_without_evidence_rejected():
    payload = _req("We like AVEA supplements for longevity.")  # naked 'AVEA' not present, so no count
    r = client.post("/v1/extract", json=payload)
    data = r.json()
    ents = {m["entity_id"] for m in data["mentions"]}
    assert "brand_avea" not in ents

def test_naked_avea_with_cobrand_counts():
    payload = _req("AVEA is good. AVEA Life makes Mobilizer.")
    r = client.post("/v1/extract", json=payload)
    data = r.json()
    ents = {m["entity_id"] for m in data["mentions"]}
    assert "brand_avea" in ents

def test_mobilizer_needs_brand_or_domain():
    payload = _req("Mobilizer improves joint health.", citations=[])
    r = client.post("/v1/extract", json=payload)
    data = r.json()
    ents = {m["entity_id"] for m in data["mentions"]}
    assert "prod_mobilizer" not in ents

    payload = _req("Mobilizer improves joint health.", citations=["https://www.avea-life.com/products/mobilizer"])
    r = client.post("/v1/extract", json=payload)
    data = r.json()
    ents = {m["entity_id"] for m in data["mentions"]}
    assert "prod_mobilizer" in ents
