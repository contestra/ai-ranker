-- 002_mentions_schema.sql
-- Evidence explainability and unique-source dedupe.

alter table entity_mentions
  add column if not exists reason_bits int default 0,
  add column if not exists source_fingerprint char(40),
  add column if not exists channel text default 'llm_answer';

create index if not exists idx_entity_mentions_fp on entity_mentions (source_fingerprint);
