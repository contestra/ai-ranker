-- 001_alias_schema.sql
-- Per-alias risk, evidence mask, weighting, and validity window.

alter table entity_aliases
  add column if not exists risk text check (risk in ('low','med','high')) default 'low',
  add column if not exists required_evidence_mask int default 0,
  add column if not exists weight real default 1.0,
  add column if not exists valid_from date,
  add column if not exists valid_to date;

create index if not exists idx_entity_aliases_lower_text on entity_aliases (lower(alias_text));
