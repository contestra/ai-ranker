# BrandX — Alias-aware Brand Entity Extractor (FastAPI)

**Purpose:** Detect brand, product, and SKU mentions in LLM answers with a single **Brand Entity** + **Alias Set**, per-alias **risk** controls, and an **evidence bitmask** to gate ambiguous names (e.g., naked token **"AVEA"**).

This is a minimal, production-friendly module: no heavy ML; explainable evidence signals; clear DB fields.

## Quickstart

```bash
# (1) Install
pip install -e .[dev]

# (2) Run tests
pytest

# (3) Start API
uvicorn brandx.service:app --reload --port 8080
```

### POST `/v1/extract`

Request:
```jsonc
{
  "org_id": "org_123",
  "run_id": "run_2025-08-14T10:00",
  "answer_text": "AVEA Life’s Mobilizer is ...",
  "citations": ["https://www.avea-life.com/products/mobilizer?utm=..."],
  "brand": {
    "entity_id": "brand_avea_life",
    "canonical_name": "AVEA Life",
    "website_domains": ["avea-life.com"],
    "signature_terms": ["longevity","NAD+","spermidine","resveratrol","collagen"],
    "geo_company_hints": ["Swiss","Switzerland","AG","Zug"],
    "retailer_domains": ["amazon.com"]
  },
  "aliases": [
    {"alias_id":"a1","entity_id":"brand_avea_life","alias_text":"AVEA Life","type":"brand","risk":"low","required_evidence_mask":0},
    {"alias_id":"a2","entity_id":"brand_avea_life","alias_text":"AVEA","type":"brand","risk":"high","required_evidence_mask":1}, // require on-domain OR any signal
    {"alias_id":"p1","entity_id":"prod_mobilizer","alias_text":"Mobilizer","type":"product","risk":"high","required_evidence_mask":2} // require co-brand or on-domain
  ]
}
```

Response:
```jsonc
{
  "mentions": [
    {
      "entity_id": "brand_avea_life",
      "alias_id": "a1",
      "start": 0, "end": 10,
      "context_excerpt": "AVEA Life’s Mobilizer is ...",
      "confidence": "high",
      "reason_bits": 2,
      "disambiguation_path": "heuristic",
      "source_fingerprint": "6f1b3..."
    },
    ...
  ],
  "rollups": {
    "brand_avea_life": {"answers_mentioned": 1, "unique_sources": 1}
  }
}
```

> Evidence bitmask (default):
> - `1 = on_domain_link`
> - `2 = co_brand`
> - `4 = product_lex`
> - `8 = signature_terms`
> - `16 = geo_company`
> - `32 = retailer_match`

### Design choices
- **Alias risk per alias** (`low|med|high`) governs disambiguation.
- **Evidence signals** are simple, inspectable string/URL checks.
- **Source fingerprint** (SHA1) dedupes identical answers/citations.
- **Explainability:** every mention returns `reason_bits` badges.

---

## Schema migrations (PostgreSQL)

See `migrations/001_alias_schema.sql` and `migrations/002_mentions_schema.sql`.

---

## UI stubs
- `ui/alias-manager/` — per-alias risk, required evidence toggles.
- `ui/results/` — results table with evidence badges & confidence chips.

Follow your project's 2025 CSS/token system. Components are minimal and semantic.
