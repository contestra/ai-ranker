import React from 'react';

type Mention = {
  entity_id: string;
  alias_id: string;
  context_excerpt: string;
  confidence: 'high'|'medium'|'low';
  reason_bits: number;
};

type Props = {
  mentions: Mention[];
  onMarkIncorrect?: (m: Mention) => void;
};

const EVIDENCE = [
  {bit: 1, label: 'On-domain link'},
  {bit: 2, label: 'Co-mention brand'},
  {bit: 4, label: 'Product lexicon'},
  {bit: 8, label: 'Signature terms'},
  {bit:16, label: 'Geo/company hint'},
  {bit:32, label: 'Retailer match'}
];

function EvidenceBadges({bits}:{bits:number}){
  return (
    <div className="evidence-badges">
      {EVIDENCE.filter(e => (bits & e.bit) !== 0).map(e => (
        <span key={e.bit} className="badge">{e.label}</span>
      ))}
    </div>
  )
}

export function ResultsTable({mentions, onMarkIncorrect}: Props){
  return (
    <section className="results-table">
      <header><h2>Mentions</h2></header>
      <div role="table" className="rt-table">
        <div role="row" className="rt-head">
          <div role="columnheader">Entity</div>
          <div role="columnheader">Alias</div>
          <div role="columnheader">Confidence</div>
          <div role="columnheader">Evidence</div>
          <div role="columnheader">Context</div>
          <div role="columnheader" aria-label="actions"></div>
        </div>
        {mentions.map((m,i)=>(
          <div role="row" key={i} className="rt-row">
            <div role="cell"><code>{m.entity_id}</code></div>
            <div role="cell"><code>{m.alias_id}</code></div>
            <div role="cell"><span className={`chip chip--${m.confidence}`}>{m.confidence}</span></div>
            <div role="cell"><EvidenceBadges bits={m.reason_bits}/></div>
            <div role="cell"><pre className="excerpt">{m.context_excerpt}</pre></div>
            <div role="cell">
              {onMarkIncorrect && (
                <button className="btn" onClick={()=>onMarkIncorrect(m)}>Mark incorrect</button>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
