// Minimal, semantic React/TS component. Wire into your design system tokens.
import React, { useState } from 'react';

type AliasRow = {
  alias_id: string;
  alias_text: string;
  type: 'brand' | 'product' | 'sku';
  risk: 'low' | 'med' | 'high';
  required_evidence_mask: number;
};

type Props = {
  aliases: AliasRow[];
  onChange: (aliases: AliasRow[]) => void;
};

const EVIDENCE = [
  {bit: 1, label: 'On-domain link'},
  {bit: 2, label: 'Co-mention brand'},
  {bit: 4, label: 'Product lexicon'},
  {bit: 8, label: 'Signature terms'},
  {bit:16, label: 'Geo/company hint'},
  {bit:32, label: 'Retailer match'}
];

export function AliasManager({aliases, onChange}: Props) {
  const [rows, setRows] = useState<AliasRow[]>(aliases);

  function updateRow(id: string, patch: Partial<AliasRow>) {
    const next = rows.map(r => r.alias_id === id ? {...r, ...patch} : r);
    setRows(next);
    onChange(next);
  }

  return (
    <section className="alias-manager" style={{containerType:'inline-size'}}>
      <header className="am-header">
        <h2>Alias Manager</h2>
        <p className="muted">Control disambiguation per alias. High-risk aliases may require evidence.</p>
      </header>

      <div className="am-table" role="table" aria-label="Aliases">
        <div role="rowgroup">
          <div role="row" className="am-row am-head">
            <div role="columnheader">Alias</div>
            <div role="columnheader">Type</div>
            <div role="columnheader">Risk</div>
            <div role="columnheader">Required evidence</div>
          </div>
        </div>
        <div role="rowgroup">
          {rows.map(r => (
            <div role="row" className="am-row" key={r.alias_id}>
              <div role="cell"><code>{r.alias_text}</code></div>
              <div role="cell">{r.type}</div>
              <div role="cell">
                <select value={r.risk} onChange={e => updateRow(r.alias_id, {risk: e.target.value as any})}>
                  <option value="low">Low</option>
                  <option value="med">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>
              <div role="cell" className="evidence">
                {EVIDENCE.map(ev => (
                  <label key={ev.bit} className="ev-chip">
                    <input
                      type="checkbox"
                      checked={(r.required_evidence_mask & ev.bit) !== 0}
                      onChange={e => {
                        const cur = r.required_evidence_mask;
                        const next = e.target.checked ? (cur | ev.bit) : (cur & ~ev.bit);
                        updateRow(r.alias_id, {required_evidence_mask: next});
                      }}
                    />
                    <span>{ev.label}</span>
                  </label>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
