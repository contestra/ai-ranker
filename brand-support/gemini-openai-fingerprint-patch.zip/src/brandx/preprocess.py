from __future__ import annotations
from typing import List, Tuple
from .utils import normalize_text, extract_urls, canonicalize_domain

def preprocess_answer(answer_text: str, citations: List[str]) -> tuple[str, List[str], List[str]]:
    text = normalize_text(answer_text or "")
    urls_in_text = extract_urls(text)
    all_urls = list({*(urls_in_text or []), *(citations or [])})
    domains = [canonicalize_domain(u) for u in all_urls]
    domains = [d for d in domains if d]
    return text, all_urls, domains
