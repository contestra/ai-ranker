from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any

Risk = str  # 'low' | 'med' | 'high'

@dataclass
class Alias:
    alias_id: str
    entity_id: str
    alias_text: str
    type: str  # 'brand' | 'product' | 'sku'
    risk: Risk = 'low'
    required_evidence_mask: int = 0   # bitmask of required signals
    weight: float = 1.0
    valid_from: Optional[str] = None
    valid_to: Optional[str] = None

@dataclass
class BrandConfig:
    entity_id: str
    canonical_name: str
    website_domains: List[str] = field(default_factory=list)
    signature_terms: List[str] = field(default_factory=list)
    geo_company_hints: List[str] = field(default_factory=list)
    retailer_domains: List[str] = field(default_factory=list)

@dataclass
class ExtractRequest:
    org_id: str
    run_id: str
    answer_text: str
    citations: List[str]
    brand: BrandConfig
    aliases: List[Alias]

@dataclass
class Mention:
    entity_id: str
    alias_id: str
    start: int
    end: int
    context_excerpt: str
    confidence: str  # 'high'|'medium'|'low'
    reason_bits: int
    disambiguation_path: str = "heuristic"
    source_fingerprint: Optional[str] = None

@dataclass
class ExtractResponse:
    mentions: List[Mention]
    rollups: Dict[str, Dict[str, Any]]
