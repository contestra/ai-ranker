from __future__ import annotations
from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import List, Dict, Any
from .model import Alias, BrandConfig, ExtractRequest, ExtractResponse, Mention
from .preprocess import preprocess_answer
from .extractor import AliasExtractor
from .evidence import (
    compute_evidence_bits, retailer_path_match,
    ON_DOMAIN, CO_BRAND, PRODUCT_LEX, SIGNATURE_TERMS, GEO_COMPANY, RETAILER_MATCH
)
from .utils import window, source_fingerprint

app = FastAPI(title="BrandX Extractor", version="0.1.0")

# Pydantic mirrors (for API I/O)
class PydAlias(BaseModel):
    alias_id: str
    entity_id: str
    alias_text: str
    type: str
    risk: str = "low"
    required_evidence_mask: int = 0
    weight: float = 1.0
    valid_from: str | None = None
    valid_to: str | None = None

class PydBrand(BaseModel):
    entity_id: str
    canonical_name: str
    website_domains: List[str] = []
    signature_terms: List[str] = []
    geo_company_hints: List[str] = []
    retailer_domains: List[str] = []

class PydExtractRequest(BaseModel):
    org_id: str
    run_id: str
    answer_text: str
    citations: List[str] = []
    brand: PydBrand
    aliases: List[PydAlias]

class PydMention(BaseModel):
    entity_id: str
    alias_id: str
    start: int
    end: int
    context_excerpt: str
    confidence: str
    reason_bits: int
    disambiguation_path: str = "heuristic"
    source_fingerprint: str | None = None

class PydExtractResponse(BaseModel):
    mentions: List[PydMention]
    rollups: Dict[str, Dict[str, Any]]

def confidence_from_bits(bits: int) -> str:
    # Strong evidence (on-domain or >=2 signals) => high; 1 signal => medium.
    strong = (bits & ON_DOMAIN) or bin(bits).count("1") >= 2
    if strong:
        return "high"
    elif bits != 0:
        return "medium"
    return "low"

@app.post("/v1/extract", response_model=PydExtractResponse)
def extract(req: PydExtractRequest) -> PydExtractResponse:
    # Convert to internal dataclasses
    brand = BrandConfig(**req.brand.model_dump())
    aliases = [Alias(**a.model_dump()) for a in req.aliases]

    text, urls, domains = preprocess_answer(req.answer_text, req.citations)
    fp = source_fingerprint(text, urls)

    extractor = AliasExtractor(aliases)
    candidates = extractor.find_candidates(text)

    # Partition aliases
    product_aliases = [a.alias_text for a in aliases if a.type in ("product","sku")]

    kept: List[Mention] = []
    counted_entities = set()

    for a, s, e in candidates:
        ctx = window(text, s, e, radius=90)

        # Compute evidence bits from context/full text
        bits = compute_evidence_bits(
            context=ctx,
            full_text=text,
            text_domains=domains,
            brand_domains=brand.website_domains,
            canonical_brand=brand.canonical_name,
            product_aliases=product_aliases,
            signature_terms=brand.signature_terms,
            geo_company_hints=brand.geo_company_hints,
            retailer_domains=brand.retailer_domains,
            brand_token_for_paths=brand.canonical_name.split()[0] if brand.canonical_name else None,
        )

        # Retailer path match check
        token = brand.canonical_name.split()[0] if brand.canonical_name else None
        if token and brand.retailer_domains and retailer_path_match(urls, brand.retailer_domains, token):
            bits |= RETAILER_MATCH

        # Risk gate
        risk = (a.risk or "low").lower()
        if risk == "low":
            pass  # accept
        else:
            # Require some evidence if medium/high
            if a.required_evidence_mask:
                # If mask is set, we require at least one of the masked bits to be present.
                if (bits & a.required_evidence_mask) == 0:
                    continue
            else:
                # Default: require at least one signal for med/high
                if bits == 0:
                    continue

        # De-dupe per (run_id, entity_id): count once per entity per answer
        key = (req.run_id, a.entity_id)
        if key in counted_entities:
            continue
        counted_entities.add(key)

        kept.append(Mention(
            entity_id=a.entity_id,
            alias_id=a.alias_id,
            start=s, end=e,
            context_excerpt=ctx,
            confidence=confidence_from_bits(bits),
            reason_bits=bits,
            disambiguation_path="heuristic",
            source_fingerprint=fp
        ))

    # Roll-ups (brand/product/sku are all 'entity_id' strings at this layer)
    rollups: Dict[str, Dict[str, Any]] = {}
    unique_sources = {}
    for m in kept:
        roll = rollups.setdefault(m.entity_id, {"answers_mentioned": 0, "unique_sources": 0})
        roll["answers_mentioned"] += 1
        # unique sources via fingerprint
        if m.entity_id not in unique_sources:
            unique_sources[m.entity_id] = set()
        if m.source_fingerprint not in unique_sources[m.entity_id]:
            unique_sources[m.entity_id].add(m.source_fingerprint)
            roll["unique_sources"] += 1

    # Map dataclasses to pydantic
    p_mentions = [PydMention(**m.__dict__) for m in kept]
    return PydExtractResponse(mentions=p_mentions, rollups=rollups)
