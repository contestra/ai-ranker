from __future__ import annotations
import re, hashlib, unicodedata
from urllib.parse import urlparse
from typing import List, Tuple

_WORD_CHARS = "A-Za-z0-9"
RE_URL = re.compile(r"https?://[^\s)\]]+")

def normalize_text(s: str) -> str:
    # Unicode NFKC + collapse spaces
    s = unicodedata.normalize("NFKC", s)
    s = s.replace("\u00A0"," ")
    s = re.sub(r"[\t\r\f]+", " ", s)
    s = re.sub(r"\s{2,}", " ", s)
    return s

def extract_urls(s: str) -> List[str]:
    return RE_URL.findall(s or "")

def canonicalize_domain(url: str) -> str:
    try:
        p = urlparse(url)
        host = (p.netloc or "").lower()
        # strip common subdomains
        if host.startswith("www."):
            host = host[4:]
        if host.startswith("m."):
            host = host[2:]
        return host
    except Exception:
        return ""

def source_fingerprint(text: str, urls: List[str]) -> str:
    # normalized lowercase text + sorted canonical domains+paths
    t = normalize_text(text).lower()
    parts = []
    for u in sorted(urls or []):
        try:
            p = urlparse(u)
            host = canonicalize_domain(u)
            path = (p.path or "").rstrip("/")
            parts.append(host + path)
        except Exception:
            parts.append(u)
    raw = t + "\n" + "|".join(parts)
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()

def window(text: str, start: int, end: int, radius: int = 75) -> str:
    lo = max(0, start - radius)
    hi = min(len(text), end + radius)
    return text[lo:hi]

def compile_alias_pattern(alias_text: str) -> re.Pattern:
    # Match word-ish boundaries; also allow # or @ prefix (hashtags/handles).
    escaped = re.escape(alias_text)
    pattern = (
        rf"(?:(?<=#)|(?<=@))(?P<alias>{escaped})(?![{_WORD_CHARS}])"
        rf"|(?<![{_WORD_CHARS}])(?P<alias2>{escaped})(?![{_WORD_CHARS}])"
    )
    return re.compile(pattern, re.IGNORECASE)
