from __future__ import annotations
from typing import List, Dict, Tuple
import re
from .model import Alias, Mention
from .utils import compile_alias_pattern, window

class AliasExtractor:
    def __init__(self, aliases: List[Alias]):
        self.aliases = aliases
        # Precompile per-alias patterns; store by alias_id
        self._patterns: Dict[str, re.Pattern] = {
            a.alias_id: compile_alias_pattern(a.alias_text) for a in self.aliases
        }

    def find_candidates(self, text: str) -> List[Tuple[Alias, int, int]]:
        out: List[Tuple[Alias, int, int]] = []
        for a in self.aliases:
            pat = self._patterns[a.alias_id]
            for m in pat.finditer(text):
                s, e = m.span()
                out.append((a, s, e))
        # Sort by start to get deterministic output
        out.sort(key=lambda t: (t[1], t[2]))
        # De-duplicate overlapping hits for same entity within same span
        dedup: List[Tuple[Alias, int, int]] = []
        seen_spans = set()
        for a, s, e in out:
            key = (a.entity_id, s, e)
            if key in seen_spans:
                continue
            seen_spans.add(key)
            dedup.append((a, s, e))
        return dedup
