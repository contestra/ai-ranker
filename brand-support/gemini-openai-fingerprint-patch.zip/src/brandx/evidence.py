from __future__ import annotations
import re
from typing import List, Set, Tuple
from .utils import canonicalize_domain

# Bitmask (keep tiny, explainable)
ON_DOMAIN = 1          # link/citation to brand domain
CO_BRAND = 2           # co-mention canonical brand
PRODUCT_LEX = 4        # product alias appears nearby
SIGNATURE_TERMS = 8    # overlap with brand signature terms
GEO_COMPANY = 16       # geo/company hints (Swiss, AG, etc.)
RETAILER_MATCH = 32    # retailer link + brand token in path

def compute_evidence_bits(
    context: str,
    full_text: str,
    text_domains: List[str],
    brand_domains: List[str],
    canonical_brand: str,
    product_aliases: List[str],
    signature_terms: List[str],
    geo_company_hints: List[str],
    retailer_domains: List[str],
    brand_token_for_paths: str | None = None,
) -> int:
    bits = 0

    # 1) On-domain link
    brand_domains = [d.lower() for d in (brand_domains or [])]
    text_domains = [d.lower() for d in (text_domains or [])]
    if any(td in brand_domains for td in text_domains):
        bits |= ON_DOMAIN

    # 2) Co-brand mention (canonical brand string anywhere in context/full text)
    if canonical_brand and re.search(re.escape(canonical_brand), context, re.IGNORECASE):
        bits |= CO_BRAND
    elif canonical_brand and re.search(re.escape(canonical_brand), full_text, re.IGNORECASE):
        bits |= CO_BRAND

    # 3) Product lexicon (any product alias nearby or in full text)
    for p in product_aliases or []:
        if re.search(rf"(?<![A-Za-z0-9]){re.escape(p)}(?![A-Za-z0-9])", context, re.IGNORECASE):
            bits |= PRODUCT_LEX
            break
    if not (bits & PRODUCT_LEX):
        for p in product_aliases or []:
            if re.search(rf"(?<![A-Za-z0-9]){re.escape(p)}(?![A-Za-z0-9])", full_text, re.IGNORECASE):
                bits |= PRODUCT_LEX
                break

    # 4) Signature terms (cheap overlap)
    sig = set(t.lower() for t in (signature_terms or []))
    if sig:
        low = context.lower()
        overlap = sum(1 for t in sig if t in low)
        if overlap >= 1:
            bits |= SIGNATURE_TERMS

    # 5) Geo/company hints
    hints = set(g.lower() for g in (geo_company_hints or []))
    if hints:
        low = context.lower()
        if any(h in low for h in hints):
            bits |= GEO_COMPANY

    # 6) Retailer match: retailer domain AND brand token in path (checked at caller if needed)
    # For simplicity, we check domains only here; path check is handled by caller if URLs are available.
    # To keep this module pure-text, we expose a helper that callers can use.
    # We'll treat domain presence as partial; caller can OR in RETAILER_MATCH if path condition holds.

    return bits

def retailer_path_match(urls: List[str], retailer_domains: List[str], brand_token: str) -> bool:
    from urllib.parse import urlparse
    rset = {d.lower() for d in (retailer_domains or [])}
    for u in urls or []:
        try:
            p = urlparse(u)
            host = p.netloc.lower()
            if host.startswith("www."):
                host = host[4:]
            if host in rset:
                if brand_token and brand_token.lower() in (p.path or "").lower():
                    return True
        except Exception:
            continue
    return False
