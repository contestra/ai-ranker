Provider-native WEB only. OpenAI + Gemini adapters included (stubs).
